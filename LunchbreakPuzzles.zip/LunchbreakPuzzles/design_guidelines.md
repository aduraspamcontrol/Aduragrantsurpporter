# DHHS Grant Program Website - Design Guidelines

## Design Approach

**Selected System**: U.S. Web Design System (USWDS) principles
**Justification**: Government service website requiring maximum trust, accessibility, and clarity. USWDS provides established patterns for institutional credibility while maintaining modern usability standards.

**Core Principles**:
- Institutional authority with approachable warmth
- Accessibility-first (WCAG 2.1 AA minimum)
- Clear information hierarchy for diverse audiences
- Trust through consistency and professionalism

---

## Typography System

**Font Families**:
- Primary: 'Source Sans Pro' (Google Fonts) - clean, government-standard sans-serif for body text
- Headings: 'Merriweather' (Google Fonts) - authoritative serif for headlines and section titles

**Type Scale**:
- Hero Headline: text-5xl md:text-6xl lg:text-7xl, font-bold
- Section Headers: text-3xl md:text-4xl, font-bold
- Subsection Headers: text-2xl md:text-3xl, font-semibold
- Body Large: text-lg md:text-xl, font-normal
- Body Standard: text-base, font-normal
- Small Text/Captions: text-sm, font-normal

---

## Layout System

**Spacing Primitives**: Use Tailwind units of **4, 6, 8, 12, 16, 20, 24** (e.g., p-4, m-8, gap-6)

**Container Structure**:
- Max width: max-w-7xl for primary content
- Section padding: py-16 md:py-24 for vertical breathing room
- Horizontal padding: px-4 md:px-8 lg:px-12
- Grid gaps: gap-8 md:gap-12 for card layouts

**Responsive Grid Patterns**:
- Single column on mobile (base)
- 2 columns on tablet (md:grid-cols-2)
- 3-4 columns on desktop (lg:grid-cols-3, xl:grid-cols-4) for feature cards and news articles

---

## Component Library

### Navigation Header
**Structure**: Sticky top navigation with logo left, menu right
- Logo area: h-16 with proper padding
- Navigation links: Horizontal menu with gap-8, text-base font-semibold
- Mobile: Hamburger menu transforming to full-screen overlay
- Accessibility: Focus states, keyboard navigation, ARIA labels

### Hero Section
**Layout**: Full-width section with background image overlay, 80vh minimum height
- Background: High-quality image of diverse individuals (healthcare workers, families, elderly, students)
- Content overlay: Centered text with semi-transparent backdrop using backdrop-blur
- Headline: text-5xl lg:text-7xl with max-w-4xl for readability
- Subheading: text-xl lg:text-2xl, max-w-3xl
- Primary CTA: Large button (px-8 py-4, text-lg) with backdrop-blur background - no hover interactions on blurred buttons
- Scroll indicator: Subtle arrow animation pointing to application form

### About Section
**Layout**: 2-column split on desktop (text + image grid)
- Left column: Program description with clear hierarchy
- Right column: 2x2 grid of authentic stock photos (healthcare workers, students, families, elderly)
- Benefit cards: Grid of 4 cards (2x2 on desktop) with icons, titles, and descriptions
- Each card: p-6, rounded-lg border, with icon at top

### Application Form Section (Google Forms Embedded)
**Implementation**: Full-width iframe container
- Section header: "Apply for the DHHS Support Program" with subtitle explaining process
- Iframe wrapper: max-w-4xl mx-auto, min-h-screen for full form visibility
- Responsive iframe: w-full, border-0, rounded-lg with subtle shadow
- Supporting text above form: Clear instructions about eligibility and required information
- Supporting text below form: Contact information for assistance

### Testimonials Section
**Layout**: 3-column carousel/grid on desktop
- Each testimonial card: Rounded border card with p-8
- Structure: Quote text (text-lg italic), attribution (name, age/occupation, location), optional photo
- Rotation: Static grid on desktop, swipeable carousel on mobile
- Minimum 6 testimonials showcasing diverse demographics

### News & Updates Section
**Layout**: 3-column grid of article cards
- Each card: Featured image (16:9 ratio), headline (text-xl font-bold), excerpt (3 lines max), "Read More" link, publication date
- Card structure: overflow-hidden rounded-lg, shadow on hover
- Filter/category tags: Optional pills above grid (Latest, Success Stories, Funding Updates)

### Footer
**Structure**: Multi-row comprehensive footer
- Top row: 4-column grid (About DHHS, Quick Links, Resources, Contact)
- Middle row: Newsletter signup with inline form (email input + submit button)
- Bottom row: Social media icons (gap-4), copyright notice, privacy policy links
- All links: Proper hover states with underline

---

## Animations & Interactions

**Minimal, Purposeful Animations**:
- Scroll-triggered fade-ins for sections (subtle 0.5s ease)
- Button hover: Slight scale (scale-105) and shadow increase - NOT on blurred buttons over images
- Card hover: Shadow elevation change (0.3s ease)
- Smooth scroll for anchor links (behavior: smooth)
- Navigation: Slide-in animation for mobile menu (0.3s ease)

**NO Animations**:
- No parallax effects
- No complex scroll-driven narratives
- No distracting motion on primary content

---

## Images

**Hero Section**: 
Large hero background image showing diverse group of smiling people receiving assistance or community support. Image should convey trust, warmth, and inclusivity. Full-width, 80vh height with overlay treatment.

**About Section Images**:
- Healthcare worker assisting patient (warm, professional)
- Student studying or graduating (hopeful, aspirational)
- Multi-generational family together (caring, supportive)
- Elderly person with caregiver (dignified, respectful)

**News Section Thumbnails**:
Generic government building, people at community event, or hands exchanging documents (professional stock imagery)

**Image Treatment**: All images use subtle overlay gradients for text legibility, border-radius for softness, and proper alt text for accessibility.

---

## Accessibility Commitments

- Semantic HTML throughout (header, nav, main, section, article, footer)
- ARIA labels on all interactive elements
- Keyboard navigation for all functionality
- Form labels properly associated with inputs
- Minimum contrast ratios: 4.5:1 for body text, 3:1 for large text
- Focus indicators on all interactive elements (ring-2 ring-offset-2)
- Skip navigation link for screen readers
- Responsive text sizing (never below 16px base)

---

## Mobile-First Responsive Strategy

**Breakpoints**:
- Mobile (base): Single column, stacked navigation
- Tablet (md: 768px): 2-column grids, horizontal navigation
- Desktop (lg: 1024px): 3-4 column grids, full layout
- Wide (xl: 1280px): Maximum width constraints, enhanced spacing

**Mobile Optimizations**:
- Hamburger menu with full-screen overlay
- Touch-friendly button sizes (min h-12)
- Simplified testimonial carousel (swipe gestures)
- Stacked form layouts
- Reduced padding to maximize content area

---

This design creates an authoritative, accessible, and trustworthy government service website that serves diverse audiences while maintaining modern web standards and exceptional usability.