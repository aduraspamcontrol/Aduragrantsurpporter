import Header from '@/components/Header';
import Hero from '@/components/Hero';
import About from '@/components/About';
import ApplicationForm from '@/components/ApplicationForm';
import Testimonials from '@/components/Testimonials';
import News from '@/components/News';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <About />
        <ApplicationForm />
        <Testimonials />
        <News />
      </main>
      <Footer />
    </div>
  );
}
