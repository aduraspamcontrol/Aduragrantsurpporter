import { Card } from '@/components/ui/card';
import { ExternalLink, FileText, HelpCircle } from 'lucide-react';

export default function ApplicationForm() {
  return (
    <section id="apply" className="py-16 md:py-24 bg-card">
      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12">
        <div className="text-center mb-12">
          <h2 className="font-serif font-bold text-3xl md:text-4xl text-foreground mb-4">
            Apply for the DHHS Support Program
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-6">
            Complete the application form below to apply for financial assistance. Our team will review your submission and contact you within 5-7 business days.
          </p>
          
          <div className="flex flex-wrap gap-4 justify-center mb-8">
            <Card className="inline-flex items-center gap-2 px-4 py-3">
              <FileText className="w-5 h-5 text-primary" />
              <span className="text-sm font-semibold text-foreground">Have documentation ready</span>
            </Card>
            <Card className="inline-flex items-center gap-2 px-4 py-3">
              <HelpCircle className="w-5 h-5 text-primary" />
              <span className="text-sm font-semibold text-foreground">Need help? Call 1-800-DHHS-HELP</span>
            </Card>
          </div>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="p-6 md:p-8">
            <div className="mb-6">
              <h3 className="font-bold text-xl text-foreground mb-3">Application Requirements</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Valid government-issued identification</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Proof of income or current financial situation</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">•</span>
                  <span>Supporting documentation for your specific need (medical bills, tuition statements, etc.)</span>
                </li>
              </ul>
            </div>

            <div className="bg-accent/30 border border-accent-border rounded-md p-6 mb-6">
              <div className="flex items-start gap-3">
                <ExternalLink className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-foreground mb-2">Google Forms Application</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    To embed your actual Google Form, create a form at forms.google.com, click "Send", select the embed option, and replace the URL below with your form's embed URL.
                  </p>
                  <div className="bg-background border border-border rounded-md p-4">
                    <code className="text-xs text-muted-foreground break-all">
                      https://docs.google.com/forms/d/e/YOUR_FORM_ID/viewform?embedded=true
                    </code>
                  </div>
                </div>
              </div>
            </div>

            <div className="w-full h-[800px] border border-border rounded-md overflow-hidden bg-background">
              <div className="h-full flex flex-col items-center justify-center gap-4 p-8 text-center">
                <ExternalLink className="w-16 h-16 text-muted-foreground/30" />
                <div>
                  <h4 className="font-bold text-xl text-foreground mb-2">Google Form Embed Placeholder</h4>
                  <p className="text-muted-foreground mb-4 max-w-md">
                    Replace this section with your Google Form embed code. Your form will appear here for applicants to complete.
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Example embed code:
                  </p>
                  <code className="text-xs bg-muted px-3 py-1 rounded-md inline-block mt-2">
                    &lt;iframe src="YOUR_GOOGLE_FORM_URL"&gt;&lt;/iframe&gt;
                  </code>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-muted/50 rounded-md">
              <p className="text-sm text-muted-foreground text-center">
                Questions about the application? Contact us at{' '}
                <a href="mailto:grants@dhhs.gov" className="text-primary font-semibold hover:underline" data-testid="link-email">
                  grants@dhhs.gov
                </a>
                {' '}or call{' '}
                <span className="text-foreground font-semibold">1-800-DHHS-HELP</span>
              </p>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}
