import { Facebook, Twitter, Linkedin, Youtube, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function Footer() {
  const quickLinks = [
    { name: 'About DHHS', href: '#about' },
    { name: 'Apply for Grants', href: '#apply' },
    { name: 'Eligibility Requirements', href: '#' },
    { name: 'FAQs', href: '#' },
  ];

  const resources = [
    { name: 'Grant Guidelines', href: '#' },
    { name: 'Application Status', href: '#' },
    { name: 'Success Stories', href: '#testimonials' },
    { name: 'Contact Support', href: '#contact' },
  ];

  const socialLinks = [
    { icon: Facebook, label: 'Facebook', href: '#' },
    { icon: Twitter, label: 'Twitter', href: '#' },
    { icon: Linkedin, label: 'LinkedIn', href: '#' },
    { icon: Youtube, label: 'YouTube', href: '#' },
  ];

  return (
    <footer id="contact" className="bg-foreground text-background">
      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12 py-12 md:py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-background text-foreground rounded-md flex items-center justify-center">
                <span className="font-bold text-lg">DHHS</span>
              </div>
              <div>
                <h3 className="font-serif font-bold text-lg">DHHS</h3>
                <p className="text-sm text-background/70">Grant Program</p>
              </div>
            </div>
            <p className="text-sm text-background/80 mb-4">
              Providing financial support and resources to empower lives, families, and communities nationwide.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-base mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-sm text-background/80 hover:text-background transition-colors hover:underline"
                    data-testid={`link-footer-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-base mb-4">Resources</h4>
            <ul className="space-y-2">
              {resources.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-sm text-background/80 hover:text-background transition-colors hover:underline"
                    data-testid={`link-footer-resource-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-base mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-sm text-background/80">
                <Mail className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <a href="mailto:grants@dhhs.gov" className="hover:text-background transition-colors hover:underline">
                  grants@dhhs.gov
                </a>
              </li>
              <li className="flex items-start gap-2 text-sm text-background/80">
                <Phone className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>1-800-DHHS-HELP</span>
              </li>
              <li className="flex items-start gap-2 text-sm text-background/80">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>200 Independence Ave, SW<br />Washington, DC 20201</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/20 pt-8 mb-8">
          <div className="max-w-md">
            <h4 className="font-bold text-base mb-3">Stay Updated</h4>
            <p className="text-sm text-background/80 mb-4">
              Subscribe to our newsletter for the latest grant opportunities and program updates.
            </p>
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                className="bg-background/10 border-background/30 text-background placeholder:text-background/50"
                data-testid="input-newsletter-email"
              />
              <Button
                variant="secondary"
                onClick={() => console.log('Newsletter signup')}
                data-testid="button-subscribe"
              >
                Subscribe
              </Button>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-t border-background/20 pt-8">
          <div className="flex items-center gap-4">
            {socialLinks.map((social, index) => (
              <Button
                key={index}
                size="icon"
                variant="ghost"
                className="text-background/80 hover:text-background"
                onClick={() => console.log('Navigate to', social.label)}
                data-testid={`button-social-${social.label.toLowerCase()}`}
              >
                <social.icon className="w-5 h-5" />
              </Button>
            ))}
          </div>

          <div className="flex flex-col md:flex-row items-center gap-4 text-sm text-background/70">
            <span>© 2025 Department of Health and Human Services</span>
            <span className="hidden md:inline">•</span>
            <a href="#" className="hover:text-background transition-colors hover:underline">
              Privacy Policy
            </a>
            <span className="hidden md:inline">•</span>
            <a href="#" className="hover:text-background transition-colors hover:underline">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
