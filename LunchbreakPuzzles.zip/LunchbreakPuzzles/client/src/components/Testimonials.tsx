import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Quote } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      quote: "The DHHS grant helped me cover my medical expenses when I needed it most. I'm forever grateful for this program.",
      name: "Sarah Mitchell",
      location: "Portland, OR",
      role: "Healthcare Grant Recipient",
      initials: "SM",
    },
    {
      quote: "As a single parent going back to school, this education grant made all the difference. I can now provide a better future for my family.",
      name: "Michael Chen",
      location: "Austin, TX",
      role: "Education Grant Recipient",
      initials: "MC",
    },
    {
      quote: "The housing assistance program gave us stability when we needed it most. Our family is thriving thanks to DHHS support.",
      name: "Jennifer Rodriguez",
      location: "Miami, FL",
      role: "Housing Assistance Recipient",
      initials: "JR",
    },
    {
      quote: "After my disability made it hard to work, DHHS provided the financial support I needed to maintain my independence and dignity.",
      name: "Robert Williams",
      location: "Chicago, IL",
      role: "Disability Support Recipient",
      initials: "RW",
    },
    {
      quote: "The program helped me access the healthcare services I desperately needed. The application process was straightforward and supportive.",
      name: "Linda Thompson",
      location: "Seattle, WA",
      role: "Healthcare Grant Recipient",
      initials: "LT",
    },
    {
      quote: "As a recent widow, the DHHS grant helped me get back on my feet during an incredibly difficult time. I'm so thankful for this support.",
      name: "Patricia Davis",
      location: "Boston, MA",
      role: "Family Support Recipient",
      initials: "PD",
    },
  ];

  return (
    <section id="testimonials" className="py-16 md:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12">
        <div className="text-center mb-12">
          <h2 className="font-serif font-bold text-3xl md:text-4xl text-foreground mb-4">
            Stories of Hope and Support
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Hear from individuals and families whose lives have been transformed by the DHHS Grant Program.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="p-6 hover-elevate" data-testid={`card-testimonial-${index}`}>
              <Quote className="w-8 h-8 text-primary/30 mb-4" />
              <p className="text-lg italic text-foreground mb-6">
                "{testimonial.quote}"
              </p>
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                    {testimonial.initials}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-bold text-foreground">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
