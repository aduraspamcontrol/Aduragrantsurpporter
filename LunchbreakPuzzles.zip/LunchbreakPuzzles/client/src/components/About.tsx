import { Heart, GraduationCap, Users, Home } from 'lucide-react';
import { Card } from '@/components/ui/card';
import healthcareImage from '@assets/generated_images/Healthcare_worker_with_patient_78f7dd1f.png';
import studentImage from '@assets/generated_images/Student_studying_511eb0f6.png';
import familyImage from '@assets/generated_images/Multi-generational_family_together_71dcd769.png';
import elderlyImage from '@assets/generated_images/Elderly_person_with_caregiver_cf08d8dc.png';

export default function About() {
  const benefits = [
    {
      icon: Heart,
      title: 'Healthcare Support',
      description: 'Assistance with medical expenses, insurance coverage, and health services for you and your family.',
    },
    {
      icon: GraduationCap,
      title: 'Education Funding',
      description: 'Grants for students, continuing education, vocational training, and skill development programs.',
    },
    {
      icon: Users,
      title: 'Family Assistance',
      description: 'Support for families including childcare, housing assistance, and essential living expenses.',
    },
    {
      icon: Home,
      title: 'Disability & Housing',
      description: 'Resources for individuals with disabilities and housing support for those in need.',
    },
  ];

  const images = [
    { src: healthcareImage, alt: 'Healthcare worker assisting patient' },
    { src: studentImage, alt: 'Student studying' },
    { src: familyImage, alt: 'Multi-generational family' },
    { src: elderlyImage, alt: 'Elderly person with caregiver' },
  ];

  return (
    <section id="about" className="py-16 md:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12">
        <div className="grid lg:grid-cols-2 gap-12 items-start mb-16">
          <div>
            <h2 className="font-serif font-bold text-3xl md:text-4xl text-foreground mb-6">
              Support for Everyone, From Every Background
            </h2>
            <p className="text-lg md:text-xl text-foreground mb-4">
              The DHHS Grant Program is committed to helping people from all walks of life — whether you're working, studying, retired, young, old, deaf or hearing, widowed, or living with a disability.
            </p>
            <p className="text-base md:text-lg text-muted-foreground mb-6">
              Our mission is to provide financial assistance and resources that make life easier and more secure for individuals, families, and communities across the nation. No matter your circumstances, we're here to help you access the support you need.
            </p>
            <p className="text-base md:text-lg text-muted-foreground">
              We offer comprehensive funding programs designed to address healthcare needs, educational opportunities, family support services, housing assistance, and disability resources.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {images.map((image, index) => (
              <div key={index} className="rounded-md overflow-hidden">
                <img
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-48 object-cover"
                  data-testid={`img-about-${index}`}
                />
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="font-serif font-bold text-2xl md:text-3xl text-foreground mb-8 text-center">
            How We Can Help
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <Card key={index} className="p-6" data-testid={`card-benefit-${index}`}>
                <div className="w-12 h-12 bg-primary/10 rounded-md flex items-center justify-center mb-4">
                  <benefit.icon className="w-6 h-6 text-primary" />
                </div>
                <h4 className="font-bold text-xl text-foreground mb-3">{benefit.title}</h4>
                <p className="text-muted-foreground">{benefit.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
