import ApplicationForm from '../ApplicationForm';

export default function ApplicationFormExample() {
  return <ApplicationForm />;
}
