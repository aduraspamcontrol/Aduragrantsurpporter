import News from '../News';

export default function NewsExample() {
  return <News />;
}
