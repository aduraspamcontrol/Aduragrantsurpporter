import { Button } from '@/components/ui/button';
import { ArrowDown } from 'lucide-react';
import heroImage from '@assets/generated_images/Diverse_community_hero_image_2990cd53.png';

interface HeroProps {
  onApplyClick?: () => void;
}

export default function Hero({ onApplyClick }: HeroProps) {
  const scrollToApply = () => {
    const applySection = document.getElementById('apply');
    if (applySection) {
      applySection.scrollIntoView({ behavior: 'smooth' });
    }
    onApplyClick?.();
  };

  return (
    <section id="home" className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/60" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-8 lg:px-12 py-16 md:py-24 text-center">
        <h1 className="font-serif font-bold text-5xl md:text-6xl lg:text-7xl text-white mb-6 max-w-4xl mx-auto">
          Helping Every Individual Live Better — The DHHS Grant Program
        </h1>
        <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto">
          Providing financial support and resources to empower lives, families, and communities.
        </p>
        <Button
          size="lg"
          onClick={scrollToApply}
          className="px-8 py-6 text-lg bg-primary/90 backdrop-blur-sm border border-primary-border hover-elevate active-elevate-2"
          data-testid="button-apply-now"
        >
          Apply Now
        </Button>
        
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ArrowDown className="w-8 h-8 text-white/70" />
        </div>
      </div>
    </section>
  );
}
