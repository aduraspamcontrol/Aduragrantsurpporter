import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, ArrowRight } from 'lucide-react';
import govBuildingImage from '@assets/generated_images/Government_building_exterior_533e675c.png';
import communityEventImage from '@assets/generated_images/Community_event_assistance_f65e854e.png';
import handshakeImage from '@assets/generated_images/Handshake_with_documents_ba0cf921.png';

export default function News() {
  const newsArticles = [
    {
      image: govBuildingImage,
      category: 'Funding Update',
      title: 'DHHS Announces $50 Million in Additional Grant Funding for 2025',
      excerpt: 'The Department of Health and Human Services has allocated an additional $50 million to expand grant programs, reaching more families and individuals in need across all 50 states.',
      date: 'January 15, 2025',
    },
    {
      image: communityEventImage,
      category: 'Success Story',
      title: 'Community Initiative Helps 10,000 Families Access Healthcare',
      excerpt: 'A recent DHHS-funded community program has successfully connected over 10,000 families with essential healthcare services, demonstrating the impact of targeted grant initiatives.',
      date: 'January 8, 2025',
    },
    {
      image: handshakeImage,
      category: 'Program Launch',
      title: 'New Disability Support Program Launches Nationwide',
      excerpt: 'DHHS introduces a comprehensive disability support program designed to provide enhanced financial assistance and resources to individuals living with disabilities.',
      date: 'December 20, 2024',
    },
  ];

  return (
    <section id="news" className="py-16 md:py-24 bg-card">
      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12">
        <div className="text-center mb-12">
          <h2 className="font-serif font-bold text-3xl md:text-4xl text-foreground mb-4">
            Latest DHHS Grant News
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Stay informed about recent funding announcements, success stories, and upcoming DHHS initiatives.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {newsArticles.map((article, index) => (
            <Card key={index} className="overflow-hidden hover-elevate" data-testid={`card-news-${index}`}>
              <div className="aspect-video overflow-hidden">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs font-semibold text-primary bg-primary/10 px-2 py-1 rounded-md">
                    {article.category}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="w-3 h-3" />
                    <span>{article.date}</span>
                  </div>
                </div>
                <h3 className="font-bold text-xl text-foreground mb-3 line-clamp-2">
                  {article.title}
                </h3>
                <p className="text-muted-foreground mb-4 line-clamp-3">
                  {article.excerpt}
                </p>
                <Button
                  variant="ghost"
                  className="p-0 h-auto font-semibold group"
                  onClick={() => console.log('Read article:', article.title)}
                  data-testid={`button-read-more-${index}`}
                >
                  Read More
                  <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
